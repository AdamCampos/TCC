/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arduinojfx;

import java.io.IOException;
import java.net.URL;
import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author BUILD
 */
public class FXMLDocumentController implements Initializable, Observer {

    @FXML
    private Label label;

    @FXML
    private TextField texto;
    
    @FXML
    private TextField textoEntrada;

    @FXML
    private void handleButtonAction(ActionEvent event) {
     
        try {

            String str = "0j";
            str = str.concat(this.texto.getText());
            
            this.main.serialPort.getOutputStream().write(str.getBytes());
            this.main.serialPort.getOutputStream().flush();
        } catch (IOException ex) {
            System.out.println("Erro na saída");
        }

    }

    private final SerialTest main = new SerialTest();

    private void iniciaThreadSerial() {

        try {

            System.out.println("Iniciando FXML");
            this.main.addObserver(this);
            this.main.initialize();

        } catch (Exception e) {
            System.out.println("Erro na aquisição do main");
        }

        try {
        } catch (Exception e) {
            //System.out.println("Erro na leitura main.getInput()");
        }

        Thread t = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                }
            }
        };

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.iniciaThreadSerial();
    }

    @Override
    public void update(Observable o, Object arg) {
        if (o.getClass().getSimpleName().equals("SerialTest")) {
             this.textoEntrada.clear();
            System.out.println("Chegando valor: " + String.valueOf(this.main.valorEntrada()));
            this.textoEntrada.setText(String.valueOf(this.main.valorEntrada()));
        }
        
    }

}
