# Bibliotecas-Display-Touch-9341

Utilização com display LCD touch 2.4" e controlador ILI9341.
